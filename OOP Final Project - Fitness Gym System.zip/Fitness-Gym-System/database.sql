CREATE DATABASE IF NOT EXISTS carreon_gym_db;

USE carreon_gym_db;

-- Table for Clients
CREATE TABLE IF NOT EXISTS clients (
    client_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    contact_number VARCHAR(20),
    current_debt DECIMAL(10, 2) DEFAULT 0.00,
    last_visit DATE
);

-- Table for Products/Packages
CREATE TABLE IF NOT EXISTS products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(50),
    price DECIMAL(10, 2)
);

-- Product/Packages names and prices
INSERT IGNORE INTO
    products (product_name, price)
VALUES ('Gym Fee', 25.00),
    ('Personal Training', 65.00),
    ('Sting', 20.00),
    ('Unli Water', 10.00),
    ('Whey Protein', 35.00),
    ('A-Max', 12.00),
    ('Tropicana', 20.00),
    ('L Carnitine', 5.00),
    ('Creatine', 5.00);

-- Table for Daily Expenses
CREATE TABLE IF NOT EXISTS expenses (
    expense_id INT AUTO_INCREMENT PRIMARY KEY,
    description VARCHAR(255),
    amount DECIMAL(10, 2),
    date_recorded DATE DEFAULT(CURRENT_DATE)
);

-- Table for Sessions (Attendance)
CREATE TABLE IF NOT EXISTS sessions (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT,
    session_date DATE DEFAULT(CURRENT_DATE),
    time_in TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    time_out TIMESTAMP NULL,
    total_bill DECIMAL(10, 2) DEFAULT 0.00,
    amount_paid DECIMAL(10, 2) DEFAULT 0.00,
    status ENUM(
        'ACTIVE',
        'COMPLETED',
        'DEBT_UNPAID'
    ) DEFAULT 'ACTIVE',
    FOREIGN KEY (client_id) REFERENCES clients (client_id)
);

-- Table for items purchased within a session
CREATE TABLE IF NOT EXISTS session_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT,
    product_name VARCHAR(50),
    price DECIMAL(10, 2),
    FOREIGN KEY (session_id) REFERENCES sessions (session_id)
);