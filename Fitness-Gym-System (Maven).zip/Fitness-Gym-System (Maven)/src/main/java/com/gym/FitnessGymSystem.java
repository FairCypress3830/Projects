// Course/Section: BSIT - 2B
// Project Made by: Boreta, Angelo L. (Leader) - Main Developer
//                  Rabe, Dave Emmanuel C.     - Support Developer/Tester
//                  Boado, Regiel Ram D.       - UI Designer (Conceptual)
//                  Selga, Rod Aeron P.        - Idea/Concept Contributor

// Project dependencies/apps used:
//  MySQL (Database Management System) - database.sql (contains query) provided in project folder
//  SQLYog - used to run queries from database.sql or just import the database.sql file
//  XAMPP - used to host local server
//  Visual Studio Code (IDE) - used to make the project
//  Extension Pack for Java - extension for java in VS Code
//  Java Development Kit (JDK) - minimum of java 8 version to run the code (FitnessGymSystem.java)
//  JDBC driver (dependency) - needed to establish connection with the database (already provided in pom.xml)
package com.gym;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FitnessGymSystem extends JFrame {
    private boolean is_dark_mode = false;
    private boolean is_large_font = false;

    private final Color act_primary = new Color(41, 128, 185); // Blue
    private final Color act_success = new Color(39, 174, 96); // Green
    private final Color act_danger = new Color(192, 57, 43); // Red
    private final Color act_warning = new Color(211, 84, 0); // Orange
    private final Color act_neutral = new Color(127, 140, 141); // Gray

    private Color col_bg;
    private Color col_panel;
    private Color col_text;
    private Color col_header;
    private Color col_tab_inactive;
    private Color col_tab_text;
    private Color col_input_bg;
    private Color col_input_text;
    private Color col_grid;

    private Font font_main;
    private Font font_bold;
    private Font font_header;
    private Font font_calc;

    private JTabbedPane tabbed_pane;
    private JTabbedPane financial_tabs;
    private JPanel main_container, header_panel;
    private JLabel title_label;
    private ModernButton btn_theme_toggle;
    private ModernButton btn_font_toggle;

    private JPanel pnl_active_sessions, pnl_financials, pnl_clients, pnl_calculator;
    private JTable tbl_active_sessions, tbl_clients, tbl_daily, tbl_monthly;
    private DefaultTableModel model_active, model_clients, model_daily_exp, model_monthly_exp;

    private List<JLabel> card_labels = new ArrayList<>();
    private List<JPanel> card_panels = new ArrayList<>();
    private List<JTable> all_tables = new ArrayList<>();
    private List<ModernButton> all_buttons = new ArrayList<>();

    private JTextField txt_calc_display;
    private boolean calculation_done = false;

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }
        SwingUtilities.invokeLater(() -> new FitnessGymSystem().setVisible(true));
    }

    public FitnessGymSystem() {
        setTitle("Luciano M. Carreon Fitness Gym System");
        setSize(1200, 700);
        setMinimumSize(new Dimension(600, 500));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        update_font_variables();
        set_theme_variables();

        UIManager.put("Panel.background", Color.WHITE);
        main_container = new JPanel(new BorderLayout());
        setContentPane(main_container);

        header_panel = new JPanel(new BorderLayout());
        header_panel.setBorder(new EmptyBorder(15, 25, 15, 25));

        title_label = new JLabel("Gym Management System");

        JPanel header_buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        header_buttons.setOpaque(false);

        btn_font_toggle = new ModernButton("Zoom: Off", act_neutral);
        btn_theme_toggle = new ModernButton("Dark Mode", act_neutral);

        btn_font_toggle.setPreferredSize(new Dimension(120, 40));
        btn_theme_toggle.setPreferredSize(new Dimension(120, 40));

        btn_font_toggle.addActionListener(e -> toggle_font_size());
        btn_theme_toggle.addActionListener(e -> toggle_theme());

        header_buttons.add(btn_font_toggle);
        header_buttons.add(btn_theme_toggle);

        header_panel.add(title_label, BorderLayout.WEST);
        header_panel.add(header_buttons, BorderLayout.EAST);
        main_container.add(header_panel, BorderLayout.NORTH);

        tabbed_pane = new JTabbedPane();

        init_active_session_panel();
        init_financial_panel();
        init_client_panel();
        init_calculator_panel();

        tabbed_pane.addTab(" Active Sessions ", pnl_active_sessions);
        tabbed_pane.addTab(" Financials ", pnl_financials);
        tabbed_pane.addTab(" Client Records ", pnl_clients);
        tabbed_pane.addTab(" Calculator ", pnl_calculator);

        main_container.add(tabbed_pane, BorderLayout.CENTER);

        apply_theme();

        try (Connection conn = DBConnection.getConnection()) {
            if (conn != null) {
                refresh_active_sessions();
                refresh_financials();
                refresh_client_list();
            }
        } catch (Exception e) {

        }
    }

    private void update_font_variables() {
        int base_size = is_large_font ? 18 : 14;
        int header_size = is_large_font ? 32 : 24;
        int calc_size = is_large_font ? 60 : 48;

        font_main = new Font("Segoe UI", Font.PLAIN, base_size);
        font_bold = new Font("Segoe UI", Font.BOLD, base_size);
        font_header = new Font("Segoe UI", Font.BOLD, header_size);
        font_calc = new Font("Monospaced", Font.BOLD, calc_size);

        UIManager.put("OptionPane.messageFont", font_main);
        UIManager.put("OptionPane.buttonFont", font_bold);
    }

    private void set_theme_variables() {
        if (is_dark_mode) {
            col_bg = new Color(18, 18, 18);
            col_panel = new Color(30, 30, 30);
            col_text = new Color(240, 240, 240);
            col_header = new Color(45, 45, 45);
            col_tab_inactive = new Color(35, 35, 35);
            col_tab_text = Color.GRAY;
            col_input_bg = new Color(50, 50, 50);
            col_input_text = Color.WHITE;
            col_grid = new Color(60, 60, 60);
        } else {
            col_bg = new Color(236, 240, 241);
            col_panel = Color.WHITE;
            col_text = new Color(44, 62, 80);
            col_header = new Color(44, 62, 80);
            col_tab_inactive = new Color(200, 200, 200);
            col_tab_text = Color.DARK_GRAY;
            col_input_bg = Color.WHITE;
            col_input_text = Color.BLACK;
            col_grid = new Color(220, 220, 220);
        }
    }

    private void toggle_theme() {
        is_dark_mode = !is_dark_mode;
        btn_theme_toggle.setText(is_dark_mode ? "Light Mode" : "Dark Mode");
        set_theme_variables();
        apply_theme();
    }

    private void toggle_font_size() {
        is_large_font = !is_large_font;
        btn_font_toggle.setText(is_large_font ? "Zoom: On" : "Zoom: Off");
        update_font_variables();
        apply_theme();
    }

    private void apply_theme() {
        main_container.setBackground(col_bg);
        header_panel.setBackground(is_dark_mode ? new Color(25, 25, 25) : new Color(44, 62, 80));
        title_label.setForeground(Color.WHITE);
        title_label.setFont(font_header);

        SwingUtilities.updateComponentTreeUI(this);

        tabbed_pane.setUI(new ModernTabUI());
        tabbed_pane.setFont(font_bold);
        financial_tabs.setUI(new ModernTabUI());
        financial_tabs.setFont(font_main);

        tabbed_pane.setBackground(col_bg);
        tabbed_pane.setForeground(col_text);
        financial_tabs.setBackground(col_bg);
        financial_tabs.setForeground(col_text);

        pnl_active_sessions.setBackground(col_bg);
        pnl_financials.setBackground(col_bg);
        pnl_clients.setBackground(col_bg);
        pnl_calculator.setBackground(col_bg);

        for (JTable t : all_tables) {
            update_table_visuals(t);
        }

        for (JPanel p : card_panels) {
            p.setBackground(col_panel);
            p.setBorder(BorderFactory.createLineBorder(is_dark_mode ? Color.GRAY : Color.LIGHT_GRAY));
        }

        for (JLabel l : card_labels) {
            l.setFont(font_main);
            l.setForeground(is_dark_mode ? Color.LIGHT_GRAY : Color.GRAY);
        }

        update_inputs(this);

        for (ModernButton b : all_buttons) {
            b.setFont(font_bold);
            b.repaint();
        }
    }

    private void update_inputs(Container container) {
        for (Component c : container.getComponents()) {
            if (c instanceof JTextField) {
                c.setFont(font_main);
                c.setBackground(col_input_bg);
                c.setForeground(col_input_text);
                ((JTextField) c).setCaretColor(col_text);
                if (c == txt_calc_display) {
                    c.setFont(font_calc);
                    c.setBackground(is_dark_mode ? new Color(10, 10, 10) : Color.WHITE);
                    c.setForeground(is_dark_mode ? Color.GREEN : Color.BLACK);
                }
            } else if (c instanceof Container && !(c instanceof JTable)) {
                update_inputs((Container) c);
            }
        }
    }

    class WrapLayout extends FlowLayout {
        public WrapLayout(int align, int hgap, int vgap) {
            super(align, hgap, vgap);
        }

        @Override
        public Dimension preferredLayoutSize(Container target) {
            return layout_size(target, true);
        }

        @Override
        public Dimension minimumLayoutSize(Container target) {
            Dimension minimum = layout_size(target, false);
            minimum.width -= (getHgap() + 1);
            return minimum;
        }

        private Dimension layout_size(Container target, boolean preferred) {
            synchronized (target.getTreeLock()) {
                int target_width = target.getSize().width;
                if (target_width == 0)
                    target_width = Integer.MAX_VALUE;

                int hgap = getHgap();
                int vgap = getVgap();
                Insets insets = target.getInsets();
                int horizontal_insets_and_gap = insets.left + insets.right + (hgap * 2);
                int max_width = target_width - horizontal_insets_and_gap;

                Dimension dim = new Dimension(0, 0);
                int row_width = 0;
                int row_height = 0;

                int nmembers = target.getComponentCount();

                for (int i = 0; i < nmembers; i++) {
                    Component m = target.getComponent(i);
                    if (m.isVisible()) {
                        Dimension d = preferred ? m.getPreferredSize() : m.getMinimumSize();
                        if (row_width + d.width > max_width) {
                            dim.width = Math.max(dim.width, row_width);
                            dim.height += row_height + vgap;
                            row_width = 0;
                            row_height = 0;
                        }
                        row_width += d.width + hgap;
                        row_height = Math.max(row_height, d.height);
                    }
                }
                dim.width = Math.max(dim.width, row_width);
                dim.height += row_height;

                dim.width += horizontal_insets_and_gap;
                dim.height += insets.top + insets.bottom + vgap * 2;

                return dim;
            }
        }
    }

    private class ModernTabUI extends BasicTabbedPaneUI {
        @Override
        protected void installDefaults() {
            super.installDefaults();
            lightHighlight = col_bg;
            shadow = col_bg;
            darkShadow = col_bg;
            focus = col_bg;
            contentBorderInsets = new Insets(0, 0, 0, 0);
        }

        @Override
        protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h,
                boolean isSelected) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (isSelected)
                g2.setColor(is_dark_mode ? new Color(60, 60, 60) : act_primary);
            else
                g2.setColor(col_tab_inactive);
            g2.fillRect(x, y, w, h);
        }

        @Override
        protected void paintText(Graphics g, int tabPlacement, Font font, FontMetrics metrics, int tabIndex,
                String title, Rectangle textRect, boolean isSelected) {
            g.setFont(font_bold);
            if (isSelected)
                g.setColor(Color.WHITE);
            else
                g.setColor(col_tab_text);
            g.drawString(title, textRect.x, textRect.y + metrics.getAscent());
        }

        @Override
        protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
        }
    }

    class ModernButton extends JButton {
        private Color base_color;
        private Color hover_color;
        private Color press_color;
        private boolean is_hovered = false;
        private boolean is_pressed = false;

        public ModernButton(String text, Color color) {
            super(text);
            this.base_color = color;
            this.hover_color = color.brighter();
            this.press_color = color.darker();
            setFont(font_bold);
            setForeground(Color.WHITE);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(150, 45));
            all_buttons.add(this);
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    is_hovered = true;
                    repaint();
                }

                public void mouseExited(MouseEvent e) {
                    is_hovered = false;
                    repaint();
                }

                public void mousePressed(MouseEvent e) {
                    is_pressed = true;
                    repaint();
                }

                public void mouseReleased(MouseEvent e) {
                    is_pressed = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (is_pressed)
                g2.setColor(press_color);
            else if (is_hovered)
                g2.setColor(hover_color);
            else
                g2.setColor(base_color);
            g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 10, 10));
            g2.setColor(getForeground());
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(getText(), (getWidth() - fm.stringWidth(getText())) / 2,
                    (getHeight() + fm.getAscent()) / 2 - 2);
            g2.dispose();
        }
    }

    private void setup_table(JTable table) {
        all_tables.add(table);
        table.setShowVerticalLines(false);
        table.setSelectionBackground(act_primary);
        table.setSelectionForeground(Color.WHITE);

        JTableHeader header = table.getTableHeader();
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row,
                        column);
                l.setBackground(col_header);
                l.setForeground(Color.WHITE);
                l.setFont(font_bold);
                l.setHorizontalAlignment(JLabel.CENTER);
                return l;
            }
        });

        DefaultTableCellRenderer center_renderer = new DefaultTableCellRenderer();
        center_renderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(center_renderer);
        }
    }

    private void update_table_visuals(JTable table) {
        table.setFont(font_main);
        table.setRowHeight(is_large_font ? 45 : 35);
        table.getTableHeader()
                .setPreferredSize(new Dimension(table.getTableHeader().getWidth(), is_large_font ? 55 : 45));
        table.getTableHeader().setFont(font_bold);

        table.setBackground(col_panel);
        table.setForeground(col_text);
        table.setGridColor(col_grid);
        table.getTableHeader().setBackground(col_header);

        if (table.getParent() instanceof JViewport) {
            ((JViewport) table.getParent()).setBackground(col_panel);
            if (table.getParent().getParent() instanceof JScrollPane) {
                ((JScrollPane) table.getParent().getParent()).setBorder(BorderFactory.createEmptyBorder());
                ((JScrollPane) table.getParent().getParent()).getViewport().setBackground(col_panel);
            }
        }
    }

    private JPanel create_stat_card(String title, JLabel value_label, Color val_color) {
        JPanel card = new JPanel(new BorderLayout());
        card_panels.add(card);

        JLabel lbl_title = new JLabel(title);
        card_labels.add(lbl_title);

        value_label.setFont(new Font("Segoe UI", Font.BOLD, 24));
        value_label.setForeground(val_color);

        card.add(lbl_title, BorderLayout.NORTH);
        card.add(value_label, BorderLayout.CENTER);
        card.setBorder(new EmptyBorder(15, 15, 15, 15));
        return card;
    }

    private void init_active_session_panel() {
        pnl_active_sessions = new JPanel(new BorderLayout(10, 10));
        pnl_active_sessions.setBorder(new EmptyBorder(20, 20, 20, 20));

        String[] cols = { "Session ID", "Client Name", "Time In", "Current Bill", "Items" };
        model_active = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        tbl_active_sessions = new JTable(model_active);
        setup_table(tbl_active_sessions);

        JScrollPane scroll = new JScrollPane(tbl_active_sessions);
        scroll.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        JPanel btn_panel = new JPanel(new WrapLayout(FlowLayout.CENTER, 15, 10));
        btn_panel.setOpaque(false);

        ModernButton btn_new = new ModernButton("New Session", act_success);
        ModernButton btn_add = new ModernButton("Add Item", act_primary);
        ModernButton btn_edit = new ModernButton("Edit Items", act_warning);
        ModernButton btn_debt = new ModernButton("Charge to Debt", act_warning);
        ModernButton btn_end = new ModernButton("Pay & End", act_primary);
        ModernButton btn_del = new ModernButton("Void Session", act_danger);
        ModernButton btn_ref = new ModernButton("Refresh", act_neutral);

        btn_panel.add(btn_new);
        btn_panel.add(btn_add);
        btn_panel.add(btn_edit);
        btn_panel.add(btn_debt);
        btn_panel.add(btn_end);
        btn_panel.add(btn_del);
        btn_panel.add(btn_ref);

        pnl_active_sessions.add(scroll, BorderLayout.CENTER);
        pnl_active_sessions.add(btn_panel, BorderLayout.SOUTH);

        btn_new.addActionListener(e -> handle_new_session());
        btn_add.addActionListener(e -> handle_add_item());
        btn_edit.addActionListener(e -> handle_edit_session_items());
        btn_debt.addActionListener(e -> handle_pay_next_time());
        btn_end.addActionListener(e -> handle_end_session());
        btn_del.addActionListener(e -> handle_delete_active_session());
        btn_ref.addActionListener(e -> refresh_active_sessions());
    }

    private JLabel lbl_daily_inc, lbl_daily_exp, lbl_daily_net;
    private JLabel lbl_monthly_inc, lbl_monthly_exp, lbl_monthly_net;

    private void init_financial_panel() {
        pnl_financials = new JPanel(new BorderLayout(10, 10));
        pnl_financials.setBorder(new EmptyBorder(10, 20, 20, 20));

        financial_tabs = new JTabbedPane();

        JPanel pnl_daily = new JPanel(new BorderLayout(10, 10));
        pnl_daily.setOpaque(false);
        pnl_daily.setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel stats_daily = new JPanel(new GridLayout(1, 3, 20, 0));
        stats_daily.setOpaque(false);
        lbl_daily_inc = new JLabel("0.00");
        lbl_daily_exp = new JLabel("0.00");
        lbl_daily_net = new JLabel("0.00");
        stats_daily.add(create_stat_card("Today's Income", lbl_daily_inc, act_success));
        stats_daily.add(create_stat_card("Today's Expenses", lbl_daily_exp, act_danger));
        stats_daily.add(create_stat_card("Today's Net", lbl_daily_net, act_primary));

        model_daily_exp = new DefaultTableModel(new String[] { "ID", "Description", "Amount", "Date" }, 0);
        tbl_daily = new JTable(model_daily_exp);
        setup_table(tbl_daily);
        pnl_daily.add(stats_daily, BorderLayout.NORTH);
        pnl_daily.add(new JScrollPane(tbl_daily), BorderLayout.CENTER);

        JPanel pnl_monthly = new JPanel(new BorderLayout(10, 10));
        pnl_monthly.setOpaque(false);
        pnl_monthly.setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel stats_monthly = new JPanel(new GridLayout(1, 3, 20, 0));
        stats_monthly.setOpaque(false);
        lbl_monthly_inc = new JLabel("0.00");
        lbl_monthly_exp = new JLabel("0.00");
        lbl_monthly_net = new JLabel("0.00");
        stats_monthly.add(create_stat_card("Monthly Income", lbl_monthly_inc, act_success));
        stats_monthly.add(create_stat_card("Monthly Expenses", lbl_monthly_exp, act_danger));
        stats_monthly.add(create_stat_card("Monthly Net", lbl_monthly_net, act_primary));

        model_monthly_exp = new DefaultTableModel(new String[] { "ID", "Description", "Amount", "Date" }, 0);
        tbl_monthly = new JTable(model_monthly_exp);
        setup_table(tbl_monthly);
        pnl_monthly.add(stats_monthly, BorderLayout.NORTH);
        pnl_monthly.add(new JScrollPane(tbl_monthly), BorderLayout.CENTER);

        financial_tabs.addTab(" Daily ", pnl_daily);
        financial_tabs.addTab(" Monthly ", pnl_monthly);

        JPanel pnl_controls = new JPanel(new WrapLayout(FlowLayout.CENTER, 10, 10));
        pnl_controls.setOpaque(false);

        JTextField txt_desc = new JTextField(15);
        txt_desc.setBorder(BorderFactory.createTitledBorder("Description"));
        JTextField txt_amt = new JTextField(10);
        txt_amt.setBorder(BorderFactory.createTitledBorder("Amount"));

        ModernButton btn_add = new ModernButton("Add Expense", act_danger);
        ModernButton btn_edit = new ModernButton("Edit", act_warning);
        ModernButton btn_del = new ModernButton("Delete", act_neutral);
        ModernButton btn_ref = new ModernButton("Refresh", act_neutral);

        pnl_controls.add(txt_desc);
        pnl_controls.add(txt_amt);
        pnl_controls.add(btn_add);
        pnl_controls.add(Box.createHorizontalStrut(20));
        pnl_controls.add(btn_edit);
        pnl_controls.add(btn_del);
        pnl_controls.add(btn_ref);

        pnl_financials.add(financial_tabs, BorderLayout.CENTER);
        pnl_financials.add(pnl_controls, BorderLayout.SOUTH);

        btn_add.addActionListener(e -> {
            Connection db_conn = DBConnection.getConnection();
            if (db_conn == null)
                return;

            try (PreparedStatement pstmt = db_conn.prepareStatement(
                    "INSERT INTO expenses (description, amount, date_recorded) VALUES (?, ?, CURRENT_DATE)")) {
                pstmt.setString(1, txt_desc.getText());
                pstmt.setDouble(2, Double.parseDouble(txt_amt.getText()));
                pstmt.executeUpdate();
                txt_desc.setText("");
                txt_amt.setText("");
                refresh_financials();
                db_conn.close();
            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number for Amount", "Input Error",
                        JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error adding expense: " + ex.getMessage());
            }
        });
        btn_edit.addActionListener(e -> handle_edit_expense());
        btn_del.addActionListener(e -> handle_delete_expense());
        btn_ref.addActionListener(e -> refresh_financials());
    }

    private void init_client_panel() {
        pnl_clients = new JPanel(new BorderLayout(10, 10));
        pnl_clients.setBorder(new EmptyBorder(20, 20, 20, 20));

        model_clients = new DefaultTableModel(new String[] { "ID", "Name", "Contact", "Debt", "Last Visit" }, 0) {
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        tbl_clients = new JTable(model_clients);
        setup_table(tbl_clients);

        JPanel pnl_ctrl = new JPanel(new WrapLayout(FlowLayout.CENTER, 15, 10));
        pnl_ctrl.setOpaque(false);

        pnl_ctrl.add(new ModernButton("Edit Client", act_primary));
        pnl_ctrl.add(new ModernButton("Delete Record", act_danger));
        pnl_ctrl.add(new ModernButton("Refresh", act_neutral));

        pnl_clients.add(new JScrollPane(tbl_clients), BorderLayout.CENTER);
        pnl_clients.add(pnl_ctrl, BorderLayout.SOUTH);

        ((ModernButton) pnl_ctrl.getComponent(0)).addActionListener(e -> handle_edit_client());
        ((ModernButton) pnl_ctrl.getComponent(1)).addActionListener(e -> handle_delete_client());
        ((ModernButton) pnl_ctrl.getComponent(2)).addActionListener(e -> refresh_client_list());
    }

    private void init_calculator_panel() {
        pnl_calculator = new JPanel(new BorderLayout(20, 20));
        pnl_calculator.setBorder(new EmptyBorder(40, 120, 40, 120));

        txt_calc_display = new JTextField("");
        txt_calc_display.setHorizontalAlignment(JTextField.RIGHT);
        txt_calc_display.setEditable(false);
        txt_calc_display.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(act_primary, 2), new EmptyBorder(15, 15, 15, 15)));

        pnl_calculator.add(txt_calc_display, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(5, 4, 10, 10));
        grid.setOpaque(false);

        String[] labels = { "C", "(", ")", "/", "7", "8", "9", "*", "4", "5", "6", "-", "1", "2", "3", "+", "0", ".",
                "DEL", "=" };

        for (String lbl : labels) {
            Color btn_color;
            if (lbl.matches("[0-9.]"))
                btn_color = act_neutral;
            else if (lbl.equals("="))
                btn_color = act_success;
            else if (lbl.equals("C") || lbl.equals("DEL"))
                btn_color = act_danger;
            else
                btn_color = act_primary;

            ModernButton btn = new ModernButton(lbl, btn_color);
            btn.addActionListener(e -> handle_calculator_input(lbl));
            grid.add(btn);
        }
        pnl_calculator.add(grid, BorderLayout.CENTER);
    }

    private void handle_calculator_input(String key) {
        if (calculation_done) {
            if (key.matches("[0-9.]"))
                txt_calc_display.setText("");
            calculation_done = false;
        }
        String current = txt_calc_display.getText();
        switch (key) {
            case "C":
                txt_calc_display.setText("");
                break;
            case "DEL":
                if (current.length() > 0)
                    txt_calc_display.setText(current.substring(0, current.length() - 1));
                break;
            case "=":
                try {
                    double result = evaluate_expression(current);
                    if (result == (long) result)
                        txt_calc_display.setText(String.format("%d", (long) result));
                    else
                        txt_calc_display.setText(String.valueOf(result));
                    calculation_done = true;
                } catch (Exception e) {
                    txt_calc_display.setText("Error");
                    calculation_done = true;
                }
                break;
            default:
                txt_calc_display.setText(current + key);
                break;
        }
    }

    private double evaluate_expression(String expression) {
        return new Object() {
            int pos = -1, ch;

            void next_char() {
                ch = (++pos < expression.length()) ? expression.charAt(pos) : -1;
            }

            boolean eat(int char_to_eat) {
                while (ch == ' ')
                    next_char();
                if (ch == char_to_eat) {
                    next_char();
                    return true;
                }
                return false;
            }

            double parse() {
                next_char();
                double x = parse_expression();
                if (pos < expression.length())
                    throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }

            double parse_expression() {
                double x = parse_term();
                for (;;) {
                    if (eat('+'))
                        x += parse_term();
                    else if (eat('-'))
                        x -= parse_term();
                    else
                        return x;
                }
            }

            double parse_term() {
                double x = parse_factor();
                for (;;) {
                    if (eat('*'))
                        x *= parse_factor();
                    else if (eat('/'))
                        x /= parse_factor();
                    else
                        return x;
                }
            }

            double parse_factor() {
                if (eat('+'))
                    return parse_factor();
                if (eat('-'))
                    return -parse_factor();
                double x;
                int start_pos = pos;
                if (eat('(')) {
                    x = parse_expression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') {
                    while ((ch >= '0' && ch <= '9') || ch == '.')
                        next_char();
                    x = Double.parseDouble(expression.substring(start_pos, pos));
                } else
                    throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }
        }.parse();
    }

    private void handle_new_session() {
        String client_name = "";
        boolean loop_name = true;

        while (loop_name) {
            client_name = JOptionPane.showInputDialog(this, "Enter Client Name:");
            if (client_name == null || client_name.trim().isEmpty())
                return;

            try (Connection db_conn = DBConnection.getConnection()) {
                if (db_conn == null)
                    return;

                int client_id = -1;
                double current_client_debt = 0.0;

                PreparedStatement pstmt_check = db_conn
                        .prepareStatement("SELECT client_id, current_debt FROM clients WHERE name = ?");
                pstmt_check.setString(1, client_name);
                ResultSet res_set_check = pstmt_check.executeQuery();

                if (res_set_check.next()) {
                    client_id = res_set_check.getInt("client_id");
                    current_client_debt = res_set_check.getDouble("current_debt");
                }

                if (client_id != -1) {
                    PreparedStatement pstmt_sess = db_conn.prepareStatement(
                            "SELECT session_id FROM sessions WHERE client_id = ? AND status = 'ACTIVE'");
                    pstmt_sess.setInt(1, client_id);
                    ResultSet res_sess = pstmt_sess.executeQuery();

                    if (res_sess.next()) {
                        int existing_session_id = res_sess.getInt("session_id");
                        Object[] options = { "Merge into Existing", "Rename Client", "Cancel" };
                        int choice = JOptionPane.showOptionDialog(this,
                                "Client '" + client_name + "' already has an ACTIVE session",
                                "Duplicate Session",
                                JOptionPane.YES_NO_CANCEL_OPTION,
                                JOptionPane.WARNING_MESSAGE,
                                null, options, options[2]);

                        if (choice == 2 || choice == -1)
                            return;
                        if (choice == 1)
                            continue;
                        if (choice == 0) {
                            List<ProductInputRow> merge_inputs = create_product_inputs();
                            JScrollPane scroll = new JScrollPane(create_product_selection_panel(merge_inputs));
                            scroll.setPreferredSize(new Dimension(400, 300));

                            if (JOptionPane.showConfirmDialog(null, scroll, "Add Items to " + client_name, 2) == 0) {
                                add_items_to_session(db_conn, existing_session_id, merge_inputs, false, 0);
                                refresh_active_sessions();
                            }
                            return;
                        }
                    }
                }

                loop_name = false;

                boolean forward_debt = false;
                double debt_to_pay_now = 0.0;
                double debt_amount_to_carry = 0.0;

                if (client_id != -1 && current_client_debt > 0) {
                    Object[] opts = { "Add to Bill", "Pay Debt", "Keep Debt", "Cancel" };
                    int choice = JOptionPane.showOptionDialog(this, "Debt: ₱" + current_client_debt, "Alert", 0, 2,
                            null, opts, opts[3]);

                    if (choice == 3 || choice == -1)
                        return;

                    if (choice == 0) {
                        forward_debt = true;
                        debt_amount_to_carry = current_client_debt;
                    } else if (choice == 1) {
                        String payment_input = JOptionPane
                                .showInputDialog("Pay amount (Debt: ₱" + current_client_debt + "):");
                        if (payment_input != null) {
                            try {
                                double payment_amount = Double.parseDouble(payment_input);
                                if (payment_amount > current_client_debt) {
                                    JOptionPane.showMessageDialog(this,
                                            "Payment exceeds debt. Taking full debt amount");
                                    debt_to_pay_now = current_client_debt;
                                } else {
                                    debt_to_pay_now = payment_amount;
                                }
                            } catch (NumberFormatException e) {
                                debt_to_pay_now = 0;
                            }
                        } else {
                            return;
                        }
                    }
                }

                List<ProductInputRow> product_inputs = create_product_inputs();
                JScrollPane scroll = new JScrollPane(create_product_selection_panel(product_inputs));
                scroll.setPreferredSize(new Dimension(400, 300));
                scroll.setBorder(null);

                int selection = JOptionPane.showConfirmDialog(null, scroll,
                        "Select Packages", JOptionPane.OK_CANCEL_OPTION);
                if (selection != JOptionPane.OK_OPTION)
                    return;

                if (client_id == -1) {
                    PreparedStatement pstmt_create = db_conn.prepareStatement(
                            "INSERT INTO clients (name, last_visit) VALUES (?, NOW())",
                            Statement.RETURN_GENERATED_KEYS);
                    pstmt_create.setString(1, client_name);
                    pstmt_create.executeUpdate();
                    ResultSet res_set_key = pstmt_create.getGeneratedKeys();
                    if (res_set_key.next())
                        client_id = res_set_key.getInt(1);
                } else {
                    db_conn.createStatement()
                            .executeUpdate("UPDATE clients SET last_visit=NOW() WHERE client_id=" + client_id);

                    if (forward_debt) {
                        update_client_debt(db_conn, client_id, 0);
                    } else if (debt_to_pay_now > 0) {
                        update_client_debt(db_conn, client_id, current_client_debt - debt_to_pay_now);
                    }
                }

                int session_id = create_session(db_conn, client_id);
                add_items_to_session(db_conn, session_id, product_inputs, forward_debt, debt_amount_to_carry);
                refresh_active_sessions();
                refresh_client_list();

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    }

    private void handle_add_item() {
        int[] rows = tbl_active_sessions.getSelectedRows();
        if (rows.length == 0) {
            JOptionPane.showMessageDialog(this, "Please select at least one session");
            return;
        }

        List<ProductInputRow> inputs = create_product_inputs();
        JScrollPane scroll = new JScrollPane(create_product_selection_panel(inputs));
        scroll.setPreferredSize(new Dimension(400, 300));

        int result = JOptionPane.showConfirmDialog(null, scroll,
                "Add Items to " + rows.length + " Session(s)", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            try (Connection db_conn = DBConnection.getConnection()) {
                if (db_conn == null)
                    return;
                db_conn.setAutoCommit(false);
                try {
                    for (int r : rows) {
                        int session_id = Integer.parseInt(model_active.getValueAt(r, 0).toString());
                        add_items_to_session(db_conn, session_id, inputs, false, 0);
                    }
                    db_conn.commit();
                    JOptionPane.showMessageDialog(this, "Items added successfully!");
                } catch (SQLException ex) {
                    db_conn.rollback();
                    throw ex;
                }
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error adding items");
            }
            refresh_active_sessions();
        }
    }

    private void handle_edit_session_items() {
        int row = tbl_active_sessions.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a session to edit items");
            return;
        }
        int session_id = Integer.parseInt(model_active.getValueAt(row, 0).toString());

        class EditItemRow {
            String name;
            double price;
            int currentQty;
            JSpinner removeSpinner;

            public EditItemRow(String name, double price, int qty) {
                this.name = name;
                this.price = price;
                this.currentQty = qty;
                this.removeSpinner = new JSpinner(new SpinnerNumberModel(0, 0, qty, 1));
            }

            public JPanel getPanel() {
                JPanel p = new JPanel(new BorderLayout(10, 0));
                p.add(new JLabel(name + " (" + currentQty + "x)"), BorderLayout.CENTER);

                JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
                right.add(new JLabel("Remove:"));
                right.add(removeSpinner);
                p.add(right, BorderLayout.EAST);
                return p;
            }
        }

        List<EditItemRow> editRows = new ArrayList<>();

        try (Connection db_conn = DBConnection.getConnection()) {
            if (db_conn == null)
                return;

            String sql = "SELECT product_name, price, COUNT(*) as qty " +
                    "FROM session_items " +
                    "WHERE session_id=" + session_id + " " +
                    "GROUP BY product_name, price";

            ResultSet res = db_conn.createStatement().executeQuery(sql);

            while (res.next()) {
                editRows.add(new EditItemRow(
                        res.getString("product_name"),
                        res.getDouble("price"),
                        res.getInt("qty")));
            }

            if (editRows.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No items in this session");
                return;
            }

            JPanel container = new JPanel(new GridLayout(0, 1, 5, 5));
            for (EditItemRow r : editRows)
                container.add(r.getPanel());

            int result = JOptionPane.showConfirmDialog(this,
                    new JScrollPane(container),
                    "Remove Items",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                double total_removed_value = 0;
                boolean changed = false;

                PreparedStatement pstmt_del = db_conn.prepareStatement(
                        "DELETE FROM session_items WHERE session_id=? AND product_name=? LIMIT ?");

                for (EditItemRow r : editRows) {
                    int qtyToRemove = (int) r.removeSpinner.getValue();

                    if (qtyToRemove > 0) {
                        pstmt_del.setInt(1, session_id);
                        pstmt_del.setString(2, r.name);
                        pstmt_del.setInt(3, qtyToRemove);
                        pstmt_del.executeUpdate();

                        total_removed_value += (qtyToRemove * r.price);
                        changed = true;
                    }
                }

                if (changed) {
                    db_conn.createStatement().executeUpdate(
                            "UPDATE sessions SET total_bill = total_bill - " + total_removed_value +
                                    " WHERE session_id=" + session_id);
                    refresh_active_sessions();
                    JOptionPane.showMessageDialog(this, "Items updated successfully");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error editing items: " + e.getMessage());
        }
    }

    private void handle_delete_active_session() {
        int[] rows = tbl_active_sessions.getSelectedRows();
        if (rows.length == 0) {
            JOptionPane.showMessageDialog(this, "Please select session(s) to void");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Void " + rows.length + " selected session(s)?\nThis cannot be undone",
                "Confirm Batch Void", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection db_conn = DBConnection.getConnection()) {
                if (db_conn == null)
                    return;
                db_conn.setAutoCommit(false);
                for (int r : rows) {
                    int session_id = Integer.parseInt(model_active.getValueAt(r, 0).toString());
                    db_conn.createStatement().execute("DELETE FROM session_items WHERE session_id=" + session_id);
                    db_conn.createStatement().execute("DELETE FROM sessions WHERE session_id=" + session_id);
                }
                db_conn.commit();
                refresh_active_sessions();
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error deleting session");
            }
        }
    }

    private void handle_pay_next_time() {
        int[] rows = tbl_active_sessions.getSelectedRows();
        if (rows.length == 0) {
            JOptionPane.showMessageDialog(this, "Select session(s) to charge");
            return;
        }

        if (JOptionPane.showConfirmDialog(this,
                "Charge bills to debt for " + rows.length + " client(s)?",
                "Batch Charge", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

            try (Connection db_conn = DBConnection.getConnection()) {
                if (db_conn == null)
                    return;
                db_conn.setAutoCommit(false);
                for (int r : rows) {
                    int session_id = Integer.parseInt(model_active.getValueAt(r, 0).toString());
                    double total_bill = Double.parseDouble(model_active.getValueAt(r, 3).toString());
                    String client_name = model_active.getValueAt(r, 1).toString();

                    int client_id = get_or_create_client(db_conn, client_name);
                    double current_debt = get_client_debt(db_conn, client_id);

                    update_client_debt(db_conn, client_id, current_debt + total_bill);
                    db_conn.createStatement().executeUpdate(
                            "UPDATE sessions SET time_out=NOW(), amount_paid=0, status='DEBT_UNPAID' WHERE session_id="
                                    + session_id);
                }
                db_conn.commit();
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Transaction failed");
            }
            refresh_active_sessions();
            refresh_client_list();
        }
    }

    private void handle_end_session() {
        int row = tbl_active_sessions.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a session to end");
            return;
        }
        int session_id = Integer.parseInt(model_active.getValueAt(row, 0).toString());
        double total_bill = Double.parseDouble(model_active.getValueAt(row, 3).toString());
        String client_name = model_active.getValueAt(row, 1).toString();
        String input_cash = JOptionPane.showInputDialog("Bill: ₱" + total_bill + "\nCash:", "0");
        if (input_cash == null)
            return;
        try (Connection db_conn = DBConnection.getConnection()) {
            if (db_conn == null)
                return;
            double cash = Double.parseDouble(input_cash);
            double change = cash - total_bill;
            double debt = 0;
            if (change < 0) {
                debt = Math.abs(change);
                update_client_debt(db_conn, get_or_create_client(db_conn, client_name),
                        get_client_debt(db_conn, get_or_create_client(db_conn, client_name)) + debt);
                JOptionPane.showMessageDialog(this, "Insufficient. Added ₱" + debt + " to debt");
            } else
                JOptionPane.showMessageDialog(this, "Change: ₱" + String.format("%.2f", change));
            PreparedStatement pstmt = db_conn
                    .prepareStatement("UPDATE sessions SET time_out=NOW(), amount_paid=?, status=? WHERE session_id=?");
            pstmt.setDouble(1, (debt > 0 ? cash : total_bill));
            pstmt.setString(2, (debt > 0 ? "DEBT_UNPAID" : "COMPLETED"));
            pstmt.setInt(3, session_id);
            pstmt.executeUpdate();
            refresh_active_sessions();
            refresh_financials();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid cash amount");
        }
    }

    private void refresh_active_sessions() {
        model_active.setRowCount(0);
        try (Connection db_conn = DBConnection.getConnection()) {
            if (db_conn == null)
                return;
            ResultSet res_set = db_conn.createStatement().executeQuery(
                    "SELECT s.session_id, c.name, s.time_in, s.total_bill FROM sessions s JOIN clients c ON s.client_id=c.client_id WHERE s.status='ACTIVE'");
            while (res_set.next())
                model_active.addRow(new Object[] { res_set.getInt(1), res_set.getString(2), res_set.getTimestamp(3),
                        res_set.getDouble(4),
                        get_items(db_conn, res_set.getInt(1)) });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String get_items(Connection db_conn, int session_id) throws SQLException {
        String sql = "SELECT product_name, COUNT(*) as qty " +
                "FROM session_items " +
                "WHERE session_id = " + session_id + " " +
                "GROUP BY product_name";

        Statement stmt = db_conn.createStatement();
        ResultSet res_set = stmt.executeQuery(sql);

        StringBuilder str_builder = new StringBuilder();

        while (res_set.next()) {
            String name = res_set.getString("product_name");
            int qty = res_set.getInt("qty");

            if (qty > 1) {
                str_builder.append(qty).append("x ").append(name);
            } else {
                str_builder.append(name);
            }
            str_builder.append(", ");
        }

        return str_builder.length() > 0 ? str_builder.substring(0, str_builder.length() - 2) : "";
    }

    private void refresh_financials() {
        refresh_rep(model_daily_exp, lbl_daily_inc, lbl_daily_exp, lbl_daily_net,
                "SELECT * FROM expenses WHERE date_recorded=CURRENT_DATE",
                "SELECT SUM(amount_paid) FROM sessions WHERE session_date=CURRENT_DATE");
        refresh_rep(model_monthly_exp, lbl_monthly_inc, lbl_monthly_exp, lbl_monthly_net,
                "SELECT * FROM expenses WHERE MONTH(date_recorded)=MONTH(CURRENT_DATE)",
                "SELECT SUM(amount_paid) FROM sessions WHERE MONTH(session_date)=MONTH(CURRENT_DATE)");
    }

    private void refresh_rep(DefaultTableModel model, JLabel lbl_in, JLabel lbl_ex, JLabel lbl_net, String query_exp,
            String query_inc) {
        model.setRowCount(0);
        double expense_total = 0, income_total = 0;
        try (Connection db_conn = DBConnection.getConnection()) {
            if (db_conn == null)
                return;
            ResultSet res_set = db_conn.createStatement().executeQuery(query_exp);
            while (res_set.next()) {
                expense_total += res_set.getDouble("amount");
                model.addRow(new Object[] { res_set.getInt(1), res_set.getString(2), res_set.getDouble(3),
                        res_set.getDate(4) });
            }
            ResultSet res_set_inc = db_conn.createStatement().executeQuery(query_inc);
            if (res_set_inc.next())
                income_total = res_set_inc.getDouble(1);
            lbl_in.setText("₱" + String.format("%.2f", income_total));
            lbl_ex.setText("₱" + String.format("%.2f", expense_total));
            lbl_net.setText("₱" + String.format("%.2f", income_total - expense_total));
        } catch (Exception x) {
            x.printStackTrace();
        }
    }

    private void refresh_client_list() {
        model_clients.setRowCount(0);
        try (Connection db_conn = DBConnection.getConnection()) {
            if (db_conn == null)
                return;
            ResultSet res_set = db_conn.createStatement().executeQuery("SELECT * FROM clients ORDER BY name");
            while (res_set.next())
                model_clients.addRow(new Object[] { res_set.getInt(1), res_set.getString(2), res_set.getString(3),
                        res_set.getDouble(4),
                        res_set.getDate(5) });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handle_edit_client() {
        int r = tbl_clients.getSelectedRow();
        if (r == -1) {
            JOptionPane.showMessageDialog(this, "Please select a client to edit");
            return;
        }
        int client_id = Integer.parseInt(model_clients.getValueAt(r, 0).toString());
        String new_name = JOptionPane.showInputDialog("Name:", model_clients.getValueAt(r, 1));
        if (new_name == null)
            return;
        String new_contact;
        while (true) {
            new_contact = JOptionPane.showInputDialog("Contact:", model_clients.getValueAt(r, 2));
            if (new_contact == null)
                return;
            if (new_contact.matches("^[+]?[0-9]+$"))
                break;
            JOptionPane.showMessageDialog(this, "Invalid contact number format");
        }
        try (Connection db_conn = DBConnection.getConnection()) {
            if (db_conn == null)
                return;
            PreparedStatement pstmt = db_conn
                    .prepareStatement("UPDATE clients SET name=?, contact_number=? WHERE client_id=?");
            pstmt.setString(1, new_name);
            pstmt.setString(2, new_contact);
            pstmt.setInt(3, client_id);
            pstmt.executeUpdate();
            refresh_client_list();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating client: " + e.getMessage());
        }
    }

    private void handle_delete_client() {
        int[] rows = tbl_clients.getSelectedRows();
        if (rows.length == 0) {
            JOptionPane.showMessageDialog(this, "Select client(s) to delete");
            return;
        }

        if (JOptionPane.showConfirmDialog(this,
                "Delete " + rows.length + " client(s)?\nWARNING: This deletes their history and debt records",
                "Confirm Delete", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

            try (Connection db_conn = DBConnection.getConnection()) {
                if (db_conn == null)
                    return;

                db_conn.setAutoCommit(false);

                PreparedStatement checkActive = db_conn.prepareStatement(
                        "SELECT COUNT(*) FROM sessions WHERE client_id = ? AND status = 'ACTIVE'");

                for (int r : rows) {
                    int client_id = Integer.parseInt(model_clients.getValueAt(r, 0).toString());
                    String client_name = model_clients.getValueAt(r, 1).toString();

                    checkActive.setInt(1, client_id);
                    ResultSet rs = checkActive.executeQuery();
                    if (rs.next() && rs.getInt(1) > 0) {
                        db_conn.rollback();
                        JOptionPane.showMessageDialog(this,
                                "Cannot delete client: '" + client_name
                                        + "'\nThey currently have an Active Session\nPlease end their session first",
                                "Action Blocked",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                for (int r : rows) {
                    int client_id = Integer.parseInt(model_clients.getValueAt(r, 0).toString());

                    db_conn.createStatement().execute(
                            "DELETE FROM session_items WHERE session_id IN (SELECT session_id FROM sessions WHERE client_id="
                                    + client_id + ")");
                    db_conn.createStatement().execute("DELETE FROM sessions WHERE client_id=" + client_id);
                    db_conn.createStatement().execute("DELETE FROM clients WHERE client_id=" + client_id);
                }
                db_conn.commit();

                refresh_client_list();
                refresh_active_sessions();
                refresh_financials();

                JOptionPane.showMessageDialog(this, "Client record(s) deleted successfully");
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error deleting client");
            }
        }
    }

    private void handle_edit_expense() {
        JTable table = (financial_tabs.getSelectedIndex() == 0) ? tbl_daily : tbl_monthly;
        int r = table.getSelectedRow();
        if (r == -1) {
            JOptionPane.showMessageDialog(this, "Please select an expense to edit");
            return;
        }
        int expense_id = Integer.parseInt(table.getModel().getValueAt(r, 0).toString());
        JTextField txt_d = new JTextField(table.getModel().getValueAt(r, 1).toString());
        JTextField txt_a = new JTextField(table.getModel().getValueAt(r, 2).toString());
        if (JOptionPane.showConfirmDialog(this, new Object[] { "Desc", txt_d, "Amt", txt_a }, "Edit", 2) == 0) {
            try (Connection db_conn = DBConnection.getConnection()) {
                if (db_conn == null)
                    return;
                try {
                    double amt = Double.parseDouble(txt_a.getText());
                    PreparedStatement pstmt = db_conn
                            .prepareStatement("UPDATE expenses SET description=?, amount=? WHERE expense_id=?");
                    pstmt.setString(1, txt_d.getText());
                    pstmt.setDouble(2, amt);
                    pstmt.setInt(3, expense_id);
                    pstmt.executeUpdate();
                    refresh_financials();
                } catch (NumberFormatException nfe) {
                    JOptionPane.showMessageDialog(this, "Invalid amount entered");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
            }
        }
    }

    private void handle_delete_expense() {
        JTable table = (financial_tabs.getSelectedIndex() == 0) ? tbl_daily : tbl_monthly;
        int[] rows = table.getSelectedRows();

        if (rows.length == 0) {
            JOptionPane.showMessageDialog(this, "Select expense(s) to delete");
            return;
        }

        if (JOptionPane.showConfirmDialog(this, "Delete " + rows.length + " expense records?", "Confirm",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try (Connection db_conn = DBConnection.getConnection()) {
                if (db_conn == null)
                    return;
                db_conn.setAutoCommit(false);
                for (int r : rows) {
                    int expense_id = Integer.parseInt(table.getModel().getValueAt(r, 0).toString());
                    db_conn.createStatement().execute("DELETE FROM expenses WHERE expense_id=" + expense_id);
                }
                db_conn.commit();
                refresh_financials();
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error deleting expense");
            }
        }
    }

    private int get_or_create_client(Connection db_conn, String client_name) throws SQLException {
        PreparedStatement pstmt = db_conn.prepareStatement("SELECT client_id FROM clients WHERE name=?");
        pstmt.setString(1, client_name);
        ResultSet res_set = pstmt.executeQuery();
        if (res_set.next())
            return res_set.getInt(1);

        PreparedStatement pstmt2 = db_conn.prepareStatement("INSERT INTO clients (name, last_visit) VALUES (?, NOW())");
        pstmt2.setString(1, client_name);
        pstmt2.executeUpdate();
        return get_or_create_client(db_conn, client_name);
    }

    private double get_client_debt(Connection db_conn, int client_id) throws SQLException {
        ResultSet res_set = db_conn.createStatement()
                .executeQuery("SELECT current_debt FROM clients WHERE client_id=" + client_id);
        return res_set.next() ? res_set.getDouble(1) : 0;
    }

    private void update_client_debt(Connection db_conn, int client_id, double amount) throws SQLException {
        db_conn.createStatement()
                .executeUpdate("UPDATE clients SET current_debt=" + amount + " WHERE client_id=" + client_id);
    }

    private int create_session(Connection db_conn, int client_id) throws SQLException {
        db_conn.createStatement()
                .executeUpdate("INSERT INTO sessions (client_id, status) VALUES (" + client_id + ", 'ACTIVE')");
        ResultSet res_set = db_conn.createStatement().executeQuery("SELECT LAST_INSERT_ID()");
        return res_set.next() ? res_set.getInt(1) : 0;
    }

    class ProductData {
        String name;
        double price;

        public ProductData(String n, double p) {
            this.name = n;
            this.price = p;
        }
    }

    private List<ProductInputRow> create_product_inputs() {
        List<ProductInputRow> inputs = new ArrayList<>();
        try (Connection db_conn = DBConnection.getConnection()) {
            if (db_conn == null)
                return inputs;
            Statement stmt = db_conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT product_name, price FROM products ORDER BY product_name ASC");
            while (rs.next()) {
                inputs.add(new ProductInputRow(rs.getString("product_name"), rs.getDouble("price")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return inputs;
    }

    private JPanel create_product_selection_panel(List<ProductInputRow> inputs) {
        JPanel p = new JPanel(new GridLayout(0, 1, 5, 5));
        for (ProductInputRow row : inputs) {
            p.add(row.getPanel());
        }

        JPanel container = new JPanel(new BorderLayout());
        container.add(p, BorderLayout.NORTH);
        return container;
    }

    private void add_items_to_session(Connection db_conn, int session_id, List<ProductInputRow> inputs,
            boolean has_prev_debt, double debt_amount) throws SQLException {

        PreparedStatement pstmt = db_conn.prepareStatement(
                "INSERT INTO session_items (session_id, product_name, price) VALUES (?,?,?)");

        double total_added = 0;

        if (has_prev_debt) {
            pstmt.setInt(1, session_id);
            pstmt.setString(2, "Prev Bal");
            pstmt.setDouble(3, debt_amount);
            pstmt.addBatch();

            total_added += debt_amount;
        }

        for (ProductInputRow row : inputs) {
            if (row.checkBox.isSelected()) {
                int qty = (int) row.quantitySpinner.getValue();
                if (!row.quantitySpinner.isEnabled())
                    qty = 1;

                for (int i = 0; i < qty; i++) {
                    pstmt.setInt(1, session_id);
                    pstmt.setString(2, row.productName);
                    pstmt.setDouble(3, row.price);
                    pstmt.addBatch();
                    total_added += row.price;
                }
            }
        }

        pstmt.executeBatch();

        db_conn.createStatement().executeUpdate(
                "UPDATE sessions SET total_bill=total_bill+" + total_added + " WHERE session_id=" + session_id);
    }

    class ProductInputRow {
        JCheckBox checkBox;
        JSpinner quantitySpinner;
        String productName;
        double price;

        public ProductInputRow(String name, double price) {
            this.productName = name;
            this.price = price;

            this.checkBox = new JCheckBox(name + " (₱" + price + ")");

            this.quantitySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));

            String lowerName = name.toLowerCase();
            boolean isRestricted = lowerName.contains("gym fee") ||
                    lowerName.contains("personal training") ||
                    lowerName.contains("unli water");

            if (isRestricted) {
                quantitySpinner.setEnabled(false);
                quantitySpinner.setToolTipText("Quantity not applicable for this item");
            }

            quantitySpinner.addChangeListener(e -> {
                if (!checkBox.isSelected())
                    checkBox.setSelected(true);
            });
        }

        public JPanel getPanel() {
            JPanel p = new JPanel(new BorderLayout(5, 0));
            p.add(checkBox, BorderLayout.CENTER);

            JPanel spinnerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
            spinnerPanel.add(new JLabel("Qty: "));
            spinnerPanel.add(quantitySpinner);

            p.add(spinnerPanel, BorderLayout.EAST);
            return p;
        }
    }
}