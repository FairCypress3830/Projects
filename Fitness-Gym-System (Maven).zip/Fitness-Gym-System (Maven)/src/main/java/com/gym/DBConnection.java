package com.gym;
import java.sql.*;
import javax.swing.*;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/carreon_gym_db";
    private static final String USER = "root";
    private static final String PASS = "";

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(URL, USER, PASS);
            return conn;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database Connection Failed!\nMake sure MySQL is running",
                    "Connection Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
}